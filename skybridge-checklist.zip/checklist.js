const SCALE = [1, 2, 3, 4];
const sections = {
  'General Skills': ['Standard precautions', 'Transmission-based isolation precautions', 'Peds code response', 'Adult code response', 'Defibrillator use'],
  'Cardiovascular': ['Angina/chest pain', 'Apical pulse rate & rhythm', 'Heart sounds (rate/rhythm) auscultation']
};
const values = {};
const app = document.getElementById('app');
Object.entries(sections).forEach(([section, items]) => {
  values[section] = {};
  const sec = document.createElement('section');
  sec.className = 'mb-6 border rounded-lg';
  sec.innerHTML = `<header class='px-4 py-2 bg-gray-50 border-b'><h2 class='font-semibold'>${section}</h2></header>`;
  items.forEach(item => {
    values[section][item] = '';
    const row = document.createElement('div');
    row.className = 'px-4 py-3 flex flex-col md:flex-row md:items-center gap-3 border-b';
    row.innerHTML = `<div class='flex-1 text-sm'>${item}</div>`;
    SCALE.forEach(n => {
      const label = document.createElement('label');
      label.className = 'inline-flex items-center gap-1 text-sm';
      const input = document.createElement('input');
      input.type = 'radio';
      input.name = `${section}::${item}`;
      input.className = 'accent-blue-600';
      input.addEventListener('change', () => values[section][item] = n);
      label.appendChild(input);
      label.appendChild(document.createTextNode(n));
      row.appendChild(label);
    });
    sec.appendChild(row);
  });
  app.appendChild(sec);
});

document.getElementById('submitBtn').addEventListener('click', async () => {
  try {
    const res = await fetch('/api/sendChecklist', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ checklist: values, type: 'Home Health RN Skills' })
    });
    if (res.ok) {
      alert('Checklist submitted successfully.');
    } else {
      alert('Error submitting checklist.');
    }
  } catch (err) {
    alert('Network error submitting checklist.');
  }
});