import sgMail from '@sendgrid/mail';
sgMail.setApiKey(process.env.SENDGRID_API_KEY);
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const { checklist, type } = req.body;
  const htmlBody = `<h1>${type}</h1><pre>${JSON.stringify(checklist, null, 2)}</pre>`;
  try {
    await sgMail.send({
      to: 'Rmastrangelo@skybridgehealthcare.com',
      from: 'no-reply@skybridgeskills.com',
      subject: `${type} Submission`,
      html: htmlBody,
    });
    res.status(200).json({ message: 'Sent' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to send email' });
  }
}